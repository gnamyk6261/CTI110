#CT1-1110
#P4HW1- Score -List
#Gnamy komi
#11/20/2023
#print('Enter 5 scores:')



num_scores = int(input("how many scores do you want to enter? "))
print()
scores = []
for i in range(num_scores):
  score = int(input(f'Enter score # {i+ 1}: '))
  while score <0 or score >100:
    print()
    print('INVALID Score!!!!')
    print('Score must be between 0 and 100')
    score = int(input(f'Enter score # {i + 1} again: '))
  scores.append(score)

min_score = min(scores)
print()

print("------------Results-------------")
print(f'Lowest Score  : {min_score}')
scores.remove(min_score)
print(f'Modified List : {scores}')



total_score =sum(scores)
average = total_score / len(scores)

print(f'Scores Average: {average}')

if average >= 90:
  print("Grade         : A")
elif average >= 80:
  print("Grade         : B")
elif average >= 70:
  print("Grade         : C")
elif average >= 60:
  print("Grade         : D")
else:
  print("Grade         : F")


print("-------------------------------------")


  


  



  
